import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


public class PersonLoader {

	public static void main(String[] args) {
		try {
			InputStream is = new FileInputStream("person.properties");
			Properties ps = new Properties();
			ps.load(is);
			
			String firstName = ps.getProperty("first_name");
			String lastName = ps.getProperty("last_name");
			String gender = ps.getProperty("gender");
			
			System.out.println("First name : " + firstName);
			System.out.println("Last name : " + lastName);
			System.out.println("Gender : " + gender);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
